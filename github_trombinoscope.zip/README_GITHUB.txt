DEPLOIEMENT GITHUB PAGES

1. Cree un depot GitHub.
2. Uploade le fichier index.html.
3. Va dans Settings > Pages.
4. Choisis Deploy from a branch.
5. Selectionne branch: main et folder: /(root).
6. Sauvegarde.
7. GitHub te donnera l'URL du site.
